import { createContext } from "react";

const StoreContext = createContext(null);

export default StoreContext;