import React from 'react'
import './AllSales.css'

function AllSales() {
  return (
    <div>
    All Sales
    </div>
  )
}

export default AllSales
